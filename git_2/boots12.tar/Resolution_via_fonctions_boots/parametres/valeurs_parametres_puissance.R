#Valeurs des paramètres définissant les fonctions des trades-off selon notre expression "puissance"
beta0=3
beta_max=5
P_beta=1

a0=3.577424
a_max=4.392827
P_a=1

alpha0=1
alpha_max=1
P_alpha=0

gamma0=1
gamma_max=1
P_gamma=0

b0=1
b_max=1
P_b=0

q=1
